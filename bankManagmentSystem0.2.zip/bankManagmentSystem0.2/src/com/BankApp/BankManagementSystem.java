package com.BankApp;

import java.util.ArrayList;
import java.util.Scanner;

 class BankAccount {

    private int accountNumber;
    private String accountHolder;
    private double balance;

    public BankAccount(int accountNumber, String accountHolder, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialDeposit;
    }

    public void deposit(double amount) {
        if (amount > 0)
        {
            balance += amount;
            System.out.println("Deposited Rs" + amount + " New balance " + balance);
        } else {
            System.out.println("Invalid Deposit amount ");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0) {
            if (balance >= amount) {
                balance -= amount;
                System.out.println("withdrew Rs" + amount + " New balance " + balance);
            } else {
                System.out.println("Insufficient fund  ");
            }
        } else {
            System.out.println("invalid withdrew amount ");
        }
    }

    public void displayBalance() {
        System.out.println("Account :-" + accountHolder + " balance" + balance);
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolder() {
        return accountHolder;
    }
}

   public class BankManagementSystem  {

    private static ArrayList<BankAccount> accounts = new ArrayList<>();
    private static int accountCounter = 1000;
    private  static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        while ( true ) {
            System.out.println("///----------Bank Management System ----------///");
            System.out.println("1. CREATE NEW ACCOUNT ");
            System.out.println("2. DEPOSIT MONEY");
            System.out.println("3. WITHDREW MONEY");
            System.out.println("4. CHECK BALANCE");
            System.out.print("5. EXIT ");
            System.out.print("ENTER CHOICE :-");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createAccount();
                    break;
                case 2:
                    performTransaction("deposit");
                    break;
                case 3:
                    performTransaction("withdrew");
                    break;
                case 4:
                    checkBalance();
                    break;
                case 5:
                    System.out.println("Exiting system");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice");
            }
        }
    }


    private static void createAccount()
    {
        System.out.print("Enter Account holder Name :-  ");
        String name = scanner.nextLine();

        double initialDeposit;
        do
        {
            System.out.print("Enter initial Deposit (min Rs: 2500) :-  RS ");
            initialDeposit = scanner.nextDouble();
        }  while (initialDeposit < 2500);

        int accountNumber = ++accountCounter;
        accounts.add(new BankAccount(accountNumber,name,initialDeposit));

        System.out.println("Account created successfully!");
        System.out.println("Account :-  " + accountNumber);
        System.out.println("Account holder :-  " + name);
        System.out.println("initialDeposit :-  " + initialDeposit);
    }

        private static BankAccount findAccount(int accountNumber)
        {
            for (BankAccount acc : accounts)
          {
            if (acc.getAccountNumber() == accountNumber)
            {
                return acc;
            }
          }
          return null;
        }

    private static void performTransaction(String type)
    {
        System.out.println("Enter account number :-");
        int accnumber = scanner.nextInt();
        BankAccount account = findAccount(accnumber);

        if (account == null)
        {
            System.out.println( "account not found");
            return;
        }

        System.out.println("Enter amount :- ");
        double amount = scanner.nextDouble();

        if (type.equals("deposit"))
        {
            account.deposit(amount);
        } else if (type.equals("withdrew")){
            account.withdraw(amount);
        }
    }

    private static void checkBalance()
    {
        System.out.println("Enter account number :- ");
        int accNumber = scanner.nextInt();
        BankAccount account = findAccount(accNumber);

         if (account == null)
         {
             System.out.println("account not found");
             return;
         }
         account.  displayBalance();
    }
}


